const express = require('express');
const router = express.Router();
const controller = require('../controllers/studentController');

router.get('/', controller.getAll);
router.get('/:id', controller.getById);
router.post('/', controller.create);
router.put('/:id', controller.updateFull);
router.patch('/:id', controller.updatePartial);
router.delete('/:id', controller.delete);

module.exports = router;