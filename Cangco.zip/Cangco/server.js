const express = require('express');
const app = express();
const studentRoutes = require('./routes/studentRoutes');

app.use(express.json()); // Essential for POST/PUT requests

app.use('/students', studentRoutes);

app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});